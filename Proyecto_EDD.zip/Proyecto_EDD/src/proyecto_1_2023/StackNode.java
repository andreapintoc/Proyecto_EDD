/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_1_2023;

/**
 *
 * @author danie
 */
public class StackNode {
     private Vertex elemento;
    private StackNode siguiente;
    
    
    /**
     * Constructor NodoPila
     * Constructor que se utilizaara al inicializar un nodo de una pila en el 
     programa
     * @author Daniela, Andrea, Yoarly
     * @param x 
     */
    
    public StackNode(Vertex x){
        elemento=x;
        siguiente=null;
    }
 /**
     * Funcion getElemento
     * En esta funcion se retornaria el elemento de un NodoPila
     * @author Daniela, Andrea, Yoarly
     * @return Vertex
     */
    public Vertex getElemento() {
        return elemento;
    }

    /**
     * Procedimiento setElemento
     * Con este procedimiento se le asignaria un valor a el elemento de un NodoPila
     * @author Daniela, Andrea, Yoarly
     * @param elemento
     */
    public void setElemento(Vertex elemento) {
        this.elemento = elemento;
    }

   /**
     * Funcion getSiguiente
     * En esta funcion se retornaria el siguiente nodo de un NodoPila
     * @author Daniela, Andrea, Yoarly
     * @return NodoPila
     */
    
    public StackNode getSiguiente() {
        return siguiente;
    }

    /**
     * Procedimiento setSiguiente
     * Con este procedimiento se le asignaria un valor a el siguiente nodo
     de un NodoPila
     * @author Daniela, Andrea, Yoarly
     * @param siguiente
     */
    public void setSiguiente(StackNode siguiente) {
        this.siguiente = siguiente;
    }
}


