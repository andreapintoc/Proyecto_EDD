/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_1_2023;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class Grafo {

    public VertexList vertices;
    public WeightList peso;
    public int numNodo;
    public int realnumNodo;
    public Vertex[] vertexarray;
    public int[][] adjacent;

    /**
     * Funcion getVertices Retorna el atributo vertices
     *
     * @author Daniela, Andrea, Yoarly
     * @return the vertices
     */
    public VertexList getVertices() {
        return vertices;

    }

    /**
     * Funcion getPeso Retorna el atributo peso
     *
     * @author Daniela, Andrea, Yoarly
     * @return the peso
     */
    public WeightList getPeso() {
        return peso;
    }

    /**
     * Funcion getNumNodo Retorna el atributo numNodo
     *
     * @author Daniela, Andrea, Yoarly
     * @return the numNodo
     */
    public int getNumNodo() {
        return numNodo;
    }

    /**
     * Funcion getVertexarray Retorna el atributo vertexarray
     *
     * @author Daniela, Andrea, Yoarly
     * @return the vertexarray
     */
    public Vertex[] getVertexarray() {
        return vertexarray;
    }

    /**
     * Funcion getAdjacent Retorna el atributo adjacent
     *
     * @author Daniela, Andrea, Yoarly
     * @return the adjacent
     */
    public int[][] getAdjacent() {
        return adjacent;
    }

    /**
     * Procedimiento MatrixGraph Crea una matriz de tamaño dado por nosotros
     *
     * @author daniela, andrea
     * @param vertices
     * @param peso
     * @param NodoId
     * @param RealNum
     */
    public Grafo(VertexList vertices, WeightList peso, int NodoId, int RealNum) {
        try {

            this.vertices = vertices;
            this.peso = peso;
            this.adjacent = new int[RealNum][RealNum];
            this.vertexarray = new Vertex[RealNum];
            for (int i = 0; i < RealNum; i++) {
                for (int j = 0; j < RealNum; j++) {
                    adjacent[i][j] = 0;
                }
                numNodo = 0;
                realnumNodo = 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha introducido un tipo de dato inválido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Procedimiento pntAllelmnt Imprime los elementos de la matriz
     *
     * @author Daniela, Andrea, Yoarly
     */
    public void pntAllelmnt() {

        for (int i = 0; i < realnumNodo; i++) {
            for (int j = 0; j < realnumNodo; j++) {
                JOptionPane.showMessageDialog(null, this.adjacent[i][j]);
            }
        }
    }

    /**
     * Procedimiento newVertex Crea el vertice de la matriz
     *
     * @author Daniela, Andrea, Yoarly
     * @param vertice
     */
    public void newVertex(Vertex vertice) {
        boolean isfound = returnIfVxFounded(vertice.getName());
        System.out.println(vertice.getName());
        if (!isfound) {
            vertexarray[realnumNodo++] = vertice;
        }

    }

    /**
     * Funcion returnIfVxFounded Devuelve verdadero si se encuentra el vertice
     * en la matriz, falso si no se consigue
     *
     * @author Daniela, Andrea, Yoarly
     * @param vertice
     * @return boolean
     */
    public boolean returnIfVxFounded(String vertice) {
        for (int i = 0; i < realnumNodo; i++) {
            if (vertice.equals(vertexarray[i].getName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Funcion getIndex Se obtiene el indice de un elemento en la matriz
     *
     * @author Daniela, Andrea, Yoarly
     * @param v
     * @return int
     */
    public int getIndex(String v) {
        for (int i = 0; i < realnumNodo; i++) {
            if (v.equals(vertexarray[i].getName())) {
                return i;
            }

        }
        return -1;
    }

    /**
     * Funcion getVertex Se obtiene el indice pero sin el numero del vertice
     *
     * @param v
     * @return int
     */
    public int getVertex(Vertex v) {
        for (int i = 0; i < realnumNodo; i++) {
            if (v.getName().equals(vertexarray[i].getName())) {
                return i;
            }

        }
        return -1;
    }

    /**
     * Procedimiento newArc Se crea un arco
     *
     * @author Daniela, Andrea, Yoarly
     * @param origen
     * @param destino
     * @param weight
     */
    public void newArc(String origen, String destino, int weight) {
        boolean founded = returnIfVxFounded(origen);
        boolean founded2 = returnIfVxFounded(destino);
        if ((founded == true) && (founded2 == true)) {
            int i = getIndex(origen);
            int j = getIndex(destino);
            adjacent[i][j] = weight;
        }
    }

    /**
     * Funcion adyacentebynum Se devuelve el arco buscado
     *
     * @author Daniela, Andrea, Yoarly
     * @param i
     * @param k
     * @return int
     */
    public int adyacentebynum(int i, int k) {
        return adjacent[i][k];
    }

    /**
     * Funcion RetornarMatriz Se imprime la matriz
     *
     * @author Daniela, Andrea, Yoarly
     * @return
     */
    public String RetornarMatriz() {
        String aux = "";
        for (int i = 0; i < this.realnumNodo; i++) {
            String line = "";
            for (int j = 0; j < this.realnumNodo; j++) {
                line += " | " + this.getAdjacent()[i][j] + " | ";
            }
            aux += line + "\n";

        }

        return aux;

    }

    public Vertex getVerbyint(int index) {
        Vertex s = this.vertexarray[index];
        return s;
    }  
}
