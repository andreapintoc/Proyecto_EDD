/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_1_2023;

/**
 *
 * @author danie
 */
public class QueueNode {
     private Vertex elemento;
     private QueueNode siguiente;
    
    /**
     * Constructor QueueNode
     * Constructor que se utilizara para inicializar las instancias de los 
     nodos de las colas
     * @author Daniela, Andrea, Yoarly
     * @param x 
     */
    
    public QueueNode (Vertex x){
        elemento=x;
        siguiente=null;
    }

    /**
     * Funcion getElemento
     * Con esta funcion se retornara el elemento
     * @author Daniela, Andrea, Yoarly
     * @return Vertex
     */
    public Vertex getElemento() {
        return elemento;
    }

     /**
     * Procedimiento setElemento
     * Con este procedimiento se le da un valor a la variable elemento
     * @author Daniela, Andrea, Yoarly
     * @param elemento the elemento to set
     */
    public void setElemento(Vertex elemento) {
        this.elemento = elemento;
    }

     /**
     * Funcion getSiguiente
     * Con esta funcion se obtiene el siguiente a un nodo
     * @author daniela, andrea
     * @return the siguiente
     */
    public QueueNode getSiguiente() {
        return siguiente;
    }

    /**
     * Procedimiento setSiguiente
     * Con este procedimiento se le da el valor a el siguiente de un nodo
     * @author Daniela, Andrea, Yoarly
     * @param siguiente the siguiente to set
     */
    public void setSiguiente(QueueNode siguiente) {
        this.siguiente = siguiente;
    }
}


